# Task 3 - Task Automation with Python

## Objective

Automate a small, real-life repetitive task using Python.

## Project

This project automatically moves all `.jpg` image files from a source folder to a destination folder.

## Concepts Used

- `os`
- `shutil`
- File and folder handling
- Loops
- Conditional statements

## How to Run

1. Make sure Python is installed.
2. Keep `task3.py` inside the project folder.
3. Create a folder named `source_folder`.
4. Put some `.jpg` files inside `source_folder`.
5. Run the program:

```bash
python task3.py
```

6. The program automatically creates `destination_folder` if it does not exist.
7. All `.jpg` files are moved from `source_folder` to `destination_folder`.

## Example Structure

```text
Task3/
├── task3.py
├── README.md
├── source_folder/
│   ├── picture1.jpg
│   └── picture2.jpg
└── destination_folder/
```

## Internship

CodeAlpha - Python Programming Internship
